#include <iostream>
using namespace std;

void nhapN(int N[], int &n)
{
    for (int i = 0; i < n; i++)
    {
        cin >> N[i];
    }
}

int linearSearchN(int N[], int n, int x)
{
    int i = 0;
    N[n] = x;
    while (N[i] != x)
        i++;
    if (i < n)
        return i;
    return -1;
}

void truyVanTimKiem(int N[], int n, int q)
{
    for (int i = 0; i < q; i++)
    {
        int x;
        cin >> x;

        int res = linearSearchN(N, n, x);

        if (res != -1)
            cout << "YES\n";
        else
            cout << "NO\n";
    }
}


int main()

{
    int n, q;
    cin >> n >> q;
    int N[n];
    nhapN(N, n);
    truyVanTimKiem(N, n, q);
    return 0;
}
