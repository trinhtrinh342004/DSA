#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

struct Computer
{
    string brand;
    double speed;
    double price;
};

bool compareBrand(const Computer& a, const Computer& b)
{
    return a.brand < b.brand;
}

bool compareSpeed(const Computer& a, const Computer& b)
{
    return a.speed > b.speed;
}

bool comparePriceSpeed(const Computer& a, const Computer& b)
{
    if (a.price != b.price)
    {
        return a.price < b.price;
    } else
    {
        return a.speed > b.speed;
    }
}

vector<Computer> filter(const vector<Computer>& computers)
{
    double p1, p2, s1, s2;
    cout << "Nhap gia tu: ";
    cin >> p1;
    cout << "Nhap gia den: ";
    cin >> p2;
    cout << "Nhap toc do xu ly tu: ";
    cin >> s1;
    cout << "Nhap toc do xu ly den: ";
    cin >> s2;

    vector<Computer> result;
    copy_if(computers.begin(), computers.end(), back_inserter(result), [p1, p2, s1, s2](const Computer& c)
    {
        return (c.price >= p1 && c.price <= p2) && (c.speed >= s1 && c.speed <= s2);
    });
    return result;
}

vector<Computer> inputComputers(int numComputers)
{
    vector<Computer> computers;
    for (int i = 0; i < numComputers; i++)
    {
        cout << "Nhap thong tin may tinh " << i + 1 << endl;
        Computer c;
        cout << "Nhap nhan hieu: ";
        cin >> c.brand;
        cout << "Nhap toc do xu ly (GHz): ";
        cin >> c.speed;
        cout << "Nhap gia ban: ";
        cin >> c.price;

        computers.push_back(c);
    }
    return computers;
}


void sortByName(vector<Computer>& computers)
{
    sort(computers.begin(), computers.end(), compareBrand);
}

void sortBySpeed(vector<Computer>& computers)
{
    sort(computers.begin(), computers.end(), compareSpeed);
}

void sort(vector<Computer>& computers)
{
    sort(computers.begin(), computers.end(), comparePriceSpeed);
}

int main()
{
    vector<Computer> computers;

    // Nhập thông tin cho từng máy tính
    int numComputers;
    cout << "Nhap so luong may tinh: ";
    cin >> numComputers;

    computers = inputComputers(numComputers);

    cout << "Original list:" << endl;
    for (const auto& c : computers)
    {
        cout << c.brand << " " << c.speed << "GHz " << c.price << "$" << endl;
    }

    sortByName(computers);
    cout << endl << "Sorted by name:" << endl;
    for (const auto& c : computers)
    {
        cout << c.brand << " " << c.speed << "GHz " << c.price << "$" << endl;
    }

    sortBySpeed(computers);
    cout << endl << "Sorted by speed:" << endl;
    for (const auto& c : computers)
    {
        cout << c.brand << " " << c.speed << "GHz " << c.price << "$" << endl;
    }

    sort(computers);
    cout << endl << "Sorted by price, then by speed:" << endl;
    for (const auto& c : computers)
    {
        cout << c.brand << " " << c.speed << "GHz " << c.price << "$" << endl;
    }

    auto filteredComputers = filter(computers);
    cout << endl << "Filtered list:" << endl;
    for (const auto& c : filteredComputers)
    {
        cout << c.brand << " " << c.speed << "GHz " << c.price << "$" << endl;
    }
   return 0;
}

