#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;

void inMangArr (vector<int> arr)
{
    for (auto ptr = arr.begin(); ptr < arr.end(); ptr++)
    {
        cout << *ptr << " ";
    }
}

int main ()
{
    int N, K;
    cin >> N;
    cin >> K;

    vector <int> arr;
    for (int i = 0; i < N; i++)
    {
        int d;
        cin >> d;
        arr.push_back(d);
    }
    rotate(arr.begin(), arr.begin()+K, arr.end());

    inMangArr(arr);
    return 0;
}
